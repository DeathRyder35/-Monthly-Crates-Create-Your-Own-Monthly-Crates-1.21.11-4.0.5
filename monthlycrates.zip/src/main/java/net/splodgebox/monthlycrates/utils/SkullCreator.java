package net.splodgebox.monthlycrates.utils;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.Skull;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.profile.PlayerProfile;
import org.bukkit.profile.PlayerTextures;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Base64;
import java.util.UUID;

/**
 * A library for the Bukkit API to create player skulls
 * from names, base64 strings, and texture URLs.
 * Updated for Minecraft 1.21 compatibility.
 */
public class SkullCreator {

    private SkullCreator() {}

    public static ItemStack createSkull() {
        return new ItemStack(Material.PLAYER_HEAD);
    }

    public static ItemStack itemFromName(String name) {
        return itemWithName(createSkull(), name);
    }

    public static ItemStack itemFromUuid(UUID id) {
        return itemWithUuid(createSkull(), id);
    }

    public static ItemStack itemFromUrl(String url) {
        return itemWithUrl(createSkull(), url);
    }

    public static ItemStack itemFromBase64(String base64) {
        return itemWithBase64(createSkull(), base64);
    }

    @Deprecated
    public static ItemStack itemWithName(ItemStack item, String name) {
        notNull(item, "item");
        notNull(name, "name");

        SkullMeta meta = (SkullMeta) item.getItemMeta();
        meta.setOwningPlayer(Bukkit.getOfflinePlayer(name));
        item.setItemMeta(meta);
        return item;
    }

    public static ItemStack itemWithUuid(ItemStack item, UUID id) {
        notNull(item, "item");
        notNull(id, "id");

        SkullMeta meta = (SkullMeta) item.getItemMeta();
        meta.setOwningPlayer(Bukkit.getOfflinePlayer(id));
        item.setItemMeta(meta);
        return item;
    }

    public static ItemStack itemWithUrl(ItemStack item, String url) {
        notNull(item, "item");
        notNull(url, "url");
        return itemWithBase64(item, urlToBase64(url));
    }

    public static ItemStack itemWithBase64(ItemStack item, String base64) {
        notNull(item, "item");
        notNull(base64, "base64");

        if (!(item.getItemMeta() instanceof SkullMeta)) return null;

        String url = extractUrlFromBase64(base64);
        if (url == null) return item;

        SkullMeta meta = (SkullMeta) item.getItemMeta();
        PlayerProfile profile = Bukkit.createPlayerProfile(UUID.randomUUID(), "MonthlyCrates");
        PlayerTextures textures = profile.getTextures();
        try {
            textures.setSkin(new URI(url).toURL());
        } catch (MalformedURLException | URISyntaxException e) {
            e.printStackTrace();
            return item;
        }
        profile.setTextures(textures);
        meta.setOwnerProfile(profile);
        item.setItemMeta(meta);
        return item;
    }

    public static void blockWithBase64(Block block, String base64) {
        notNull(block, "block");
        notNull(base64, "base64");

        block.setType(Material.PLAYER_HEAD, false);
        Skull state = (Skull) block.getState();

        String url = extractUrlFromBase64(base64);
        if (url == null) return;

        PlayerProfile profile = Bukkit.createPlayerProfile(UUID.randomUUID(), "MonthlyCrates");
        PlayerTextures textures = profile.getTextures();
        try {
            textures.setSkin(new URI(url).toURL());
        } catch (MalformedURLException | URISyntaxException e) {
            e.printStackTrace();
            return;
        }
        profile.setTextures(textures);
        state.setOwnerProfile(profile);
        state.update(false, false);
    }

    private static String extractUrlFromBase64(String base64) {
        try {
            String decoded = new String(Base64.getDecoder().decode(base64));
            // Expected format: {"textures":{"SKIN":{"url":"https://..."}}}
            int urlStart = decoded.indexOf("\"url\":\"") + 7;
            int urlEnd = decoded.indexOf("\"", urlStart);
            if (urlStart < 7 || urlEnd < 0) return null;
            return decoded.substring(urlStart, urlEnd);
        } catch (Exception e) {
            return null;
        }
    }

    private static String urlToBase64(String url) {
        URI actualUrl;
        try {
            actualUrl = new URI(url);
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }
        String toEncode = "{\"textures\":{\"SKIN\":{\"url\":\"" + actualUrl.toString() + "\"}}}";
        return Base64.getEncoder().encodeToString(toEncode.getBytes());
    }

    private static void notNull(Object o, String name) {
        if (o == null) {
            throw new NullPointerException(name + " should not be null!");
        }
    }
}

