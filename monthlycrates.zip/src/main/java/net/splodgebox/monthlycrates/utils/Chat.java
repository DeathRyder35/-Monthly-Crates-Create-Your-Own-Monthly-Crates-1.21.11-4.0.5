package net.splodgebox.monthlycrates.utils;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Chat {

    private static final Pattern HEX_PATTERN = Pattern.compile("#[a-fA-F0-9]{6}");

    public static String color(String message) {
        if (message == null || message.isEmpty())
            return message;

        return translate(message);
    }

    public static void msg(Player player, String... messages) {
        Arrays.stream(messages).forEach(s -> player.sendMessage(color(s)));
    }

    public static void msg(CommandSender sender, String... messages) {
        Arrays.stream(messages).forEach(s -> sender.sendMessage(color(s)));
    }

    public static void msgAll(String... messages) {
        Bukkit.getOnlinePlayers().forEach(o ->
                Arrays.stream(messages).forEach(s -> o.sendMessage(color(s))));
    }

    public static void log(String message) {
        Bukkit.getConsoleSender().sendMessage(color(message));
    }

    public static String translate(String message) {
        // Translate #RRGGBB hex colours to §x§R§R§G§G§B§B format
        Matcher matcher = HEX_PATTERN.matcher(message);
        StringBuffer sb = new StringBuffer();
        while (matcher.find()) {
            String hex = matcher.group();
            StringBuilder replacement = new StringBuilder("§x");
            for (char c : hex.substring(1).toCharArray()) {
                replacement.append('§').append(c);
            }
            matcher.appendReplacement(sb, replacement.toString());
        }
        matcher.appendTail(sb);
        message = sb.toString();

        return ChatColor.translateAlternateColorCodes('&', message);
    }
}