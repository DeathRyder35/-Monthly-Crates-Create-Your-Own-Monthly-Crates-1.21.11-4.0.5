package net.splodgebox.monthlycrates.data;

import com.cryptomorin.xseries.XMaterial;
import com.google.common.collect.ImmutableMap;
import de.tr7zw.changeme.nbtapi.NBT;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import net.splodgebox.monthlycrates.utils.ItemStackBuilder;
import net.splodgebox.monthlycrates.utils.ItemUtils;
import net.splodgebox.monthlycrates.utils.Pair;
import net.splodgebox.monthlycrates.utils.SkullCreator;
import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.UUID;

@Getter
@RequiredArgsConstructor
public class Crate {

    private final String id;
    private final String title;
    private final String name;
    private final List<String> lore;
    private final XMaterial material;
    private final List<String> nbt;
    private final int customModelData;
    private final String data;

    private final List<XMaterial> colors;
    private final int shuffleTime;
    private final boolean duplicateReward;
    private final ItemStack fillerPane;
    private final ItemStack hiddenPane;
    private final ItemStack lockedPane;
    private final ItemStack finalPane;

    private final List<Pair<Double, Reward>> bonusRewards;
    private final List<Pair<Double, Reward>> rewards;

    public ItemStack create(String player) {
        ItemStack itemStack;

        if (material == XMaterial.PLAYER_HEAD && data != null && !data.isEmpty()) {
            itemStack = SkullCreator.itemFromBase64(data);
        } else {
            itemStack = material.parseItem();
        }


        itemStack =  new ItemStackBuilder(itemStack)
                .setName(name)
                .setLore(lore)
                .setNBT("MonthlyCrates", id)
                .setNBT("NoStack", UUID.randomUUID().toString())
                .build(ImmutableMap.of("%player%", player));

        if (!nbt.isEmpty()) {
            NBT.modify(itemStack, readWriteItemNBT -> {
                nbt.stream()
                        .map(tag -> tag.split(":"))
                        .forEach(index -> readWriteItemNBT.setString(index[0], index[1]));
            });
        }

        if (customModelData > 0) {
            itemStack = ItemUtils.setCustomModelData(itemStack, customModelData);
        }

        return itemStack;
    }

}
